#
# TABLE STRUCTURE FOR: banner
#

DROP TABLE IF EXISTS `banner`;

CREATE TABLE `banner` (
  `id_banner` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `link` varchar(200) DEFAULT NULL,
  `gambar` varchar(200) DEFAULT NULL,
  `publish` enum('Y','N') NOT NULL DEFAULT 'Y',
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `posisi` varchar(20) DEFAULT NULL,
  `urutan` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_banner`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `banner` (`id_banner`, `judul`, `link`, `gambar`, `publish`, `tanggal`, `posisi`, `urutan`) VALUES (3, 'detail 2', '#', '500a32d394aa95c529fece649fa2121d.jpg', 'Y', '2022-01-01 00:43:23', '5', 1);
INSERT INTO `banner` (`id_banner`, `judul`, `link`, `gambar`, `publish`, `tanggal`, `posisi`, `urutan`) VALUES (8, 'Kanan atas', '#', '420de6618a041e70b8466b44fd8ae4b6.jpg', 'Y', '2022-01-01 00:43:30', '3', 1);
INSERT INTO `banner` (`id_banner`, `judul`, `link`, `gambar`, `publish`, `tanggal`, `posisi`, `urutan`) VALUES (10, 'Kanan bawah', '#', 'a5106c2cb78227934b67d47c7fe9a169.jpg', 'Y', '2022-01-01 00:43:38', '4', 1);
INSERT INTO `banner` (`id_banner`, `judul`, `link`, `gambar`, `publish`, `tanggal`, `posisi`, `urutan`) VALUES (11, 'Home Tengah', '#', 'b43b68fd1830e3c6ff9d680c15ddd70c.png', 'Y', '2022-01-01 00:43:47', '2', 1);
INSERT INTO `banner` (`id_banner`, `judul`, `link`, `gambar`, `publish`, `tanggal`, `posisi`, `urutan`) VALUES (13, 'iklan header', '#', 'f1a3073086c4b2a47cb702645cf0e204.png', 'Y', '2022-01-01 00:43:13', '7', 1);
INSERT INTO `banner` (`id_banner`, `judul`, `link`, `gambar`, `publish`, `tanggal`, `posisi`, `urutan`) VALUES (14, 'Tengah atas', '#', '24be303f9f83561e7183ab245346892b.png', 'Y', '2022-01-01 00:43:53', '1', 1);


#
# TABLE STRUCTURE FOR: cat
#

DROP TABLE IF EXISTS `cat`;

CREATE TABLE `cat` (
  `id_cat` int(11) NOT NULL AUTO_INCREMENT,
  `id_parent` int(11) NOT NULL DEFAULT 0,
  `nama_kategori` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `rubrik` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'category',
  `kategori_seo` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `css_class` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `pub` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `mods` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `show_mob` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `urutan` varchar(3) COLLATE latin1_general_ci NOT NULL DEFAULT '10',
  `urutan_mobile` varchar(2) COLLATE latin1_general_ci NOT NULL DEFAULT 'X',
  PRIMARY KEY (`id_cat`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `cat` (`id_cat`, `id_parent`, `nama_kategori`, `rubrik`, `kategori_seo`, `css_class`, `pub`, `aktif`, `mods`, `show_mob`, `urutan`, `urutan_mobile`) VALUES (1, 0, 'PEMERINTAHAN', 'rubrik', 'pemerintahan', '', 'Y', 'Y', 'N', 'Y', '1', 'X');
INSERT INTO `cat` (`id_cat`, `id_parent`, `nama_kategori`, `rubrik`, `kategori_seo`, `css_class`, `pub`, `aktif`, `mods`, `show_mob`, `urutan`, `urutan_mobile`) VALUES (2, 0, 'NASIONAL', 'rubrik', 'nasional', '', 'Y', 'Y', 'N', 'Y', '2', 'X');
INSERT INTO `cat` (`id_cat`, `id_parent`, `nama_kategori`, `rubrik`, `kategori_seo`, `css_class`, `pub`, `aktif`, `mods`, `show_mob`, `urutan`, `urutan_mobile`) VALUES (3, 0, 'POLITIK', 'rubrik', 'politik', '', 'Y', 'Y', 'Y', 'Y', '3', 'X');
INSERT INTO `cat` (`id_cat`, `id_parent`, `nama_kategori`, `rubrik`, `kategori_seo`, `css_class`, `pub`, `aktif`, `mods`, `show_mob`, `urutan`, `urutan_mobile`) VALUES (8, 0, 'PERISTIWA', 'rubrik', 'peristiwa', '', 'Y', 'Y', 'N', 'Y', '6', 'X');
INSERT INTO `cat` (`id_cat`, `id_parent`, `nama_kategori`, `rubrik`, `kategori_seo`, `css_class`, `pub`, `aktif`, `mods`, `show_mob`, `urutan`, `urutan_mobile`) VALUES (9, 0, 'HUKUM', 'rubrik', 'hukum', '', 'Y', 'Y', 'N', 'Y', '7', 'X');
INSERT INTO `cat` (`id_cat`, `id_parent`, `nama_kategori`, `rubrik`, `kategori_seo`, `css_class`, `pub`, `aktif`, `mods`, `show_mob`, `urutan`, `urutan_mobile`) VALUES (10, 0, 'BISNIS', 'rubrik', 'bisnis', '', 'Y', 'Y', 'N', 'Y', '8', 'X');


#
# TABLE STRUCTURE FOR: gtbl_user
#

DROP TABLE IF EXISTS `gtbl_user`;

CREATE TABLE `gtbl_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `google_id` varchar(150) DEFAULT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `idmenu` tinytext DEFAULT NULL,
  `id_level` varchar(100) DEFAULT '2',
  `idlevel` varchar(50) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `pass_two` varchar(255) DEFAULT NULL,
  `nama_lengkap` varchar(100) DEFAULT NULL,
  `daftar` date DEFAULT NULL,
  `tgl_daftar` datetime DEFAULT NULL,
  `alamat` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `no_hp` varchar(30) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL,
  `id_lock` int(11) NOT NULL DEFAULT 0,
  `aktif` enum('Y','N') NOT NULL DEFAULT 'Y',
  `hak_akses` int(11) NOT NULL DEFAULT 0,
  `id_session` varchar(100) DEFAULT NULL,
  `verify` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `google_id` (`google_id`)
) ENGINE=MyISAM AUTO_INCREMENT=413 DEFAULT CHARSET=latin1;

INSERT INTO `gtbl_user` (`id_user`, `google_id`, `parent`, `idmenu`, `id_level`, `idlevel`, `username`, `password`, `pass_two`, `nama_lengkap`, `daftar`, `tgl_daftar`, `alamat`, `email`, `no_hp`, `profile_image`, `level`, `id_lock`, `aktif`, `hak_akses`, `id_session`, `verify`) VALUES (2, NULL, 0, '1,2,24,33,109,112,114,116,117,140,141,144,146,156,167,168,169,170', '1', '1,2,3,4', 'admin', '$2y$10$l8JlLgS4k3ynSgtjc2B5b.kgzg2pBMmtj/jovMNCW6BICRR4aPA6a', '$2y$10$ve992eTK.MCNz2M9P1Mz0OcNwLS441L3054xxzrxbet/IfHDHJ8vW', 'Administrator', NULL, '2020-08-28 00:00:00', 'Serang Banten', 'admin@bantennetwork.co.id', '089611274798', 'https://i.ibb.co/17c1z0w/x5v5i1641063179357.png', 'admin', 1, 'Y', 0, 'bee0-71a0-f4ea-b4cd-df1a', 1);


#
# TABLE STRUCTURE FOR: hak_akses
#

DROP TABLE IF EXISTS `hak_akses`;

CREATE TABLE `hak_akses` (
  `id_level` int(11) NOT NULL,
  `id_parent` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `level` varchar(20) NOT NULL,
  `publish` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_level`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `hak_akses` (`id_level`, `id_parent`, `nama`, `level`, `publish`) VALUES (1, 0, 'Administrator', 'admin', 'Y');
INSERT INTO `hak_akses` (`id_level`, `id_parent`, `nama`, `level`, `publish`) VALUES (2, 0, 'Pengguna', 'user', 'Y');
INSERT INTO `hak_akses` (`id_level`, `id_parent`, `nama`, `level`, `publish`) VALUES (3, 0, 'Manager', 'manager', 'Y');
INSERT INTO `hak_akses` (`id_level`, `id_parent`, `nama`, `level`, `publish`) VALUES (4, 0, 'Editor', 'editor', 'Y');
INSERT INTO `hak_akses` (`id_level`, `id_parent`, `nama`, `level`, `publish`) VALUES (5, 0, 'Publisher', 'publisher', 'Y');
INSERT INTO `hak_akses` (`id_level`, `id_parent`, `nama`, `level`, `publish`) VALUES (6, 0, 'Wartawan', 'wartawan', 'Y');


#
# TABLE STRUCTURE FOR: iklan
#

DROP TABLE IF EXISTS `iklan`;

CREATE TABLE `iklan` (
  `id_iklan` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL,
  `autoplay` enum('controls autoplay','controls') NOT NULL,
  `tanggal` datetime NOT NULL,
  `publish` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_iklan`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `iklan` (`id_iklan`, `judul`, `url`, `autoplay`, `tanggal`, `publish`) VALUES (3, 'Bupati Tanggerang - Zaki Iskandar', 'https://streamable.com/s/ihom8/yntfpy', 'controls autoplay', '2019-03-24 00:00:00', 'N');


#
# TABLE STRUCTURE FOR: info
#

DROP TABLE IF EXISTS `info`;

CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_website` varchar(100) NOT NULL,
  `alamat_website` varchar(100) NOT NULL,
  `meta_deskripsi` varchar(250) NOT NULL,
  `meta_keyword` varchar(250) NOT NULL,
  `email` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `id_map` varchar(50) NOT NULL,
  `facebook` varchar(200) NOT NULL,
  `twitter` varchar(200) NOT NULL,
  `gplus` varchar(200) NOT NULL,
  `instagram` varchar(200) NOT NULL,
  `favicon` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `info` (`id`, `nama_website`, `alamat_website`, `meta_deskripsi`, `meta_keyword`, `email`, `alamat`, `id_map`, `facebook`, `twitter`, `gplus`, `instagram`, `favicon`) VALUES (1, 'LenteraNewsTV', 'https://lenteranews.tv/', 'LenteraNewsTV', 'berita banten, lenteranews tv, lenteranews, banten update', 'lenteranews.tv@gmail.com', '<h2><strong>Alamat Redaksi &amp; Sales</strong></h2>\r\n\r\n<p><strong>Tower Lenteranews</strong></p>\r\n\r\n<p><strong>JL. Berhias No.32 Kelurahan Pasar Baru</strong></p>\r\n\r\n<p><strong>Kota Tangerang, Provinsi Banten</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n', '-', '-', '-', '-', '-', 'favicon.ico');


#
# TABLE STRUCTURE FOR: kotak_masuk
#

DROP TABLE IF EXISTS `kotak_masuk`;

CREATE TABLE `kotak_masuk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pesan` text COLLATE utf8_unicode_ci NOT NULL,
  `tanggal` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `kotak_masuk` (`id`, `pesan`, `tanggal`, `status`) VALUES (3, '{\"name\":\"Munajat\",\"email\":\"rangkasku@gmail.com\",\"judul\":\"cara membuat website\",\"message\":\"bagaimana cara membuat website seperti ini\"}', '2018-10-04 15:38:29', 1);
INSERT INTO `kotak_masuk` (`id`, `pesan`, `tanggal`, `status`) VALUES (4, '{\"name\":\"Munajat\",\"email\":\"rangkasku@gmail.com\",\"judul\":\"cara membuat website\",\"message\":\"bagaimana cara membuat website seperti ini\"}', '2018-10-04 15:38:37', 1);
INSERT INTO `kotak_masuk` (`id`, `pesan`, `tanggal`, `status`) VALUES (5, '{\"name\":\"Munajat\",\"email\":\"rangkasku@gmail.com\",\"judul\":\"cara membuat website\",\"message\":\"bagaimana cara membuat website seperti ini\"}', '2018-10-04 15:39:32', 1);
INSERT INTO `kotak_masuk` (`id`, `pesan`, `tanggal`, `status`) VALUES (6, '{\"name\":\"Munajat\",\"email\":\"rangkasku@gmail.com\",\"judul\":\"cara membuat website\",\"message\":\"bagaimana cara membuat website seperti ini\"}', '2018-10-04 15:40:05', 1);
INSERT INTO `kotak_masuk` (`id`, `pesan`, `tanggal`, `status`) VALUES (7, '{\"name\":\"Munajat\",\"email\":\"rangkasku@gmail.com\",\"judul\":\"cara membuat website\",\"message\":\"cara membuat website\"}', '2018-10-04 15:40:45', 1);
INSERT INTO `kotak_masuk` (`id`, `pesan`, `tanggal`, `status`) VALUES (8, '{\"name\":\"Munajat\",\"email\":\"rangkasku@gmail.com\",\"judul\":\"cara membuat website\",\"message\":\"cara membuat website\"}', '2018-10-04 15:43:21', 1);
INSERT INTO `kotak_masuk` (`id`, `pesan`, `tanggal`, `status`) VALUES (9, '{\"name\":\"Munajat\",\"email\":\"rangkasku@gmail.com\",\"judul\":\"cara membuat website\",\"message\":\"bagaimana cara membuat website yang bagus\"}', '2018-10-04 15:46:13', 1);
INSERT INTO `kotak_masuk` (`id`, `pesan`, `tanggal`, `status`) VALUES (10, '{\"name\":\"Munajat\",\"email\":\"rangkasku@gmail.com\",\"judul\":\"cara membuat website\",\"message\":\"cara membuat website\"}', '2018-10-04 15:49:31', 1);


#
# TABLE STRUCTURE FOR: label
#

DROP TABLE IF EXISTS `label`;

CREATE TABLE `label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `slug` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `color` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `label` (`id`, `name`, `slug`, `color`) VALUES (1, 'Spot Wisata', 'spot-wisata', '#69008c');
INSERT INTO `label` (`id`, `name`, `slug`, `color`) VALUES (2, 'Sergap', 'sergap', '#ff0000');
INSERT INTO `label` (`id`, `name`, `slug`, `color`) VALUES (3, 'Dialog Pagi', 'dialog-pagi', '#FF6768');
INSERT INTO `label` (`id`, `name`, `slug`, `color`) VALUES (4, 'Harus Tau', 'harus-tau', '#0E6385');
INSERT INTO `label` (`id`, `name`, `slug`, `color`) VALUES (5, 'Entertaint', 'entertaint', '#071252');


#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `idmenu` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(20) DEFAULT NULL,
  `nama_menu` varchar(100) DEFAULT NULL,
  `link` text DEFAULT NULL,
  `app` varchar(100) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `aktif` enum('Y','N') NOT NULL DEFAULT 'Y',
  `sub_menu` enum('Y','N') NOT NULL DEFAULT 'N',
  `short` int(11) NOT NULL DEFAULT 0,
  `id_level` int(11) NOT NULL DEFAULT 3,
  `home` int(11) NOT NULL DEFAULT 0,
  `title` varchar(100) DEFAULT NULL,
  `treeview` varchar(100) DEFAULT NULL,
  `icon` varchar(200) DEFAULT NULL,
  `style` text DEFAULT NULL,
  `position` enum('Top','Bottom') NOT NULL DEFAULT 'Bottom',
  `urutan` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idmenu`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (1, '', 'HOME', '', '', 0, 'Y', 'N', 0, 3, 0, '', '', '', '', 'Bottom', 6);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (10, '', 'PEMERINTAHAN', 'rubrik/pemerintahan', '', 0, 'Y', 'N', 0, 1, 0, '', '', '', '', 'Bottom', 7);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (5, '', 'Redaksi', '/page/redaksi', '', 0, 'Y', 'N', 0, 3, 0, '', '', '', '', 'Top', 0);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (29, '', 'NASIONAL', 'rubrik/nasional', '', 0, 'Y', 'N', 0, 1, 0, '', '', '', '', 'Bottom', 8);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (30, '', 'POLITIK', 'rubrik/politik', '', 0, 'Y', 'N', 0, 1, 0, '', '', '', '', 'Bottom', 9);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (8, '', 'Info Iklan', '/page/info-iklan', '', 0, 'Y', 'N', 0, 3, 0, '', '', '', '', 'Top', 1);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (31, '', 'PERISTIWA', 'rubrik/peristiwa', '', 0, 'Y', 'N', 0, 1, 0, '', '', '', '', 'Bottom', 10);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (32, '', 'HUKUM', 'rubrik/hukum', '', 0, 'Y', 'N', 0, 1, 0, '', '', '', '', 'Bottom', 11);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (33, '', 'Pedoman Siber', '/page/pedoman-siber', '', 0, 'Y', 'N', 0, 3, 0, '', '', '', '', 'Top', 2);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (34, NULL, 'About Us', '/page/about-us', NULL, 0, 'Y', 'N', 0, 3, 0, NULL, NULL, '', NULL, 'Top', 3);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (35, NULL, 'Disclaimer', '/page/disclaimer', NULL, 0, 'Y', 'N', 0, 3, 0, NULL, NULL, '', NULL, 'Top', 4);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (36, NULL, 'Copyright', '/page/copyright', NULL, 0, 'Y', 'N', 0, 3, 0, NULL, NULL, '', NULL, 'Top', 5);
INSERT INTO `menu` (`idmenu`, `category`, `nama_menu`, `link`, `app`, `parent_id`, `aktif`, `sub_menu`, `short`, `id_level`, `home`, `title`, `treeview`, `icon`, `style`, `position`, `urutan`) VALUES (38, NULL, 'BISNIS', 'rubrik/bisnis', NULL, 0, 'Y', 'N', 0, 1, 0, NULL, '', '', NULL, 'Bottom', 13);


#
# TABLE STRUCTURE FOR: menuadmin
#

DROP TABLE IF EXISTS `menuadmin`;

CREATE TABLE `menuadmin` (
  `idmenu` int(11) NOT NULL AUTO_INCREMENT,
  `idparent` int(11) NOT NULL DEFAULT 0,
  `id_level` tinytext DEFAULT NULL,
  `nama_menu` varchar(200) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `link_on` enum('Y','N') NOT NULL DEFAULT 'Y',
  `treeview` varchar(10) NOT NULL DEFAULT 'treeview',
  `classes` varchar(20) DEFAULT NULL,
  `classicon` enum('Y','N') NOT NULL DEFAULT 'Y',
  `icon` varchar(20) DEFAULT NULL,
  `aktif` enum('Y','N') NOT NULL DEFAULT 'Y',
  `level` varchar(100) DEFAULT NULL,
  `urutan` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idmenu`)
) ENGINE=MyISAM AUTO_INCREMENT=171 DEFAULT CHARSET=latin1;

INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (1, 0, '1,2,4', 'MASTER DATA', '#', 'N', 'header', 'bars', 'Y', '', 'Y', '', 9);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (144, 0, '1,2,3,4', 'Profile', 'akun/profil', 'N', '', NULL, 'Y', 'fa-user-circle', 'Y', NULL, 5);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (24, 0, '1', 'Menu Admin', 'main/menuadmin', 'N', '', '', 'N', 'fa-bars', 'Y', 'admin', 15);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (33, 141, '1,2,3', 'Pengguna', 'master/pengguna', 'Y', 'treeview', 'menu5', 'N', 'fa-user', 'Y', 'admin', 7);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (2, 0, '1,2,3,4', 'Beranda', 'home', 'N', '', 'home4', 'N', '', 'N', '', 0);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (109, 116, '1', 'Berita', 'berita/post', 'Y', '', 'menu5', 'N', 'book', 'Y', '', 2);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (112, 0, '1', 'PENGATURAN', '#pengaturan', 'Y', 'treeview', 'settings', 'Y', 'fa-cog', 'Y', '', 10);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (114, 116, '1', 'Rubrik', 'berita/kategori', 'Y', '', 'bars', 'N', '', 'Y', '', 3);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (116, 0, '1', 'POSTING', '#posting', 'Y', 'treeview', 'icon-newspaper-o', 'Y', 'fa-book', 'Y', '', 1);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (117, 116, '1', 'Halaman', 'berita/page', 'Y', 'treeview', 'bars', 'N', '', 'Y', '', 4);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (140, 0, '1', 'Database', 'backupdb', 'N', 'a', 'icon-database', 'Y', 'fa-database', 'Y', NULL, 16);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (141, 0, '1,2,3,4', 'Akun', '#', 'Y', 'treeview', 'icon-user', 'Y', 'fa-user', 'Y', NULL, 6);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (146, 112, '1', 'Website', 'info/website', 'N', '', NULL, 'Y', '', 'Y', NULL, 11);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (156, 0, '1', 'Version 2.0', '#', 'N', 'header', NULL, 'Y', '', 'Y', NULL, 17);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (167, 0, '1', 'Iklan', 'iklan', 'N', '', NULL, 'Y', 'fa-image', 'Y', NULL, 8);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (168, 0, '1', 'Menusite', 'menu', 'N', '', NULL, 'Y', 'fa-th-list', 'Y', NULL, 14);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (169, 112, '1', 'Sosmed', 'setting/sosmed', 'N', '', NULL, 'Y', '', 'Y', NULL, 12);
INSERT INTO `menuadmin` (`idmenu`, `idparent`, `id_level`, `nama_menu`, `link`, `link_on`, `treeview`, `classes`, `classicon`, `icon`, `aktif`, `level`, `urutan`) VALUES (170, 112, '1', 'Widget', 'setting/widget', 'N', '', NULL, 'Y', '', 'Y', NULL, 13);


#
# TABLE STRUCTURE FOR: page
#

DROP TABLE IF EXISTS `page`;

CREATE TABLE `page` (
  `id_page` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(200) NOT NULL,
  `judul_seo` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `update_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `pub` int(11) NOT NULL DEFAULT 0,
  `photo` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_page`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=305;

INSERT INTO `page` (`id_page`, `judul`, `judul_seo`, `isi`, `create_date`, `update_date`, `pub`, `photo`, `status`) VALUES (6, 'Pedoman Siber', 'pedoman-siber', '<h2><strong>Pedoman Pemberitaan Media Siber</strong></h2>\r\n\r\n<p>Kemerdekaan berpendapat, kemerdekaan berekspresi, dan kemerdekaan pers adalah hak asasi manusia yang dilindungi Pancasila, Undang-Undang Dasar 1945, dan Deklarasi Universal Hak Asasi Manusia PBB. Keberadaan media siber di Indonesia juga merupakan bagian dari kemerdekaan berpendapat, kemerdekaan berekspresi, dan kemerdekaan pers.</p>\r\n\r\n<p>Media siber memiliki karakter khusus sehingga memerlukan pedoman agar pengelolaannya dapat dilaksanakan secara profesional, memenuhi fungsi, hak, dan kewajibannya sesuai Undang-Undang Nomor 40 Tahun 1999 tentang Pers dan Kode Etik Jurnalistik. Untuk itu Dewan Pers bersama organisasi pers, pengelola media siber, dan masyarakat menyusun Pedoman Pemberitaan Media Siber sebagai berikut:</p>\r\n\r\n<p><strong>1. Ruang Lingkup</strong></p>\r\n\r\n<ol>\r\n <li>Media Siber adalah segala bentuk media yang menggunakan wahana internet dan melaksanakan kegiatan jurnalistik, serta memenuhi persyaratan Undang-Undang Pers dan Standar Perusahaan Pers yang ditetapkan Dewan Pers.</li>\r\n <li>Isi Buatan Pengguna (User Generated Content) adalah segala isi yang dibuat dan atau dipublikasikan oleh pengguna media siber, antara lain, artikel, gambar, komentar, suara, video dan berbagai bentuk unggahan yang melekat pada media siber, seperti blog, forum, komentar pembaca atau pemirsa, dan bentuk lain.</li>\r\n</ol>\r\n\r\n<p><br>\r\n<strong>2. Verifikasi dan keberimbangan berita</strong></p>\r\n\r\n<ol>\r\n <li>Pada prinsipnya setiap berita harus melalui verifikasi.</li>\r\n <li>Berita yang dapat merugikan pihak lain memerlukan verifikasi pada berita yang sama untuk memenuhi prinsip akurasi dan keberimbangan.</li>\r\n <li>Ketentuan dalam butir (a) di atas dikecualikan, dengan syarat:\r\n <ol>\r\n  <li>Berita benar-benar mengandung kepentingan publik yang bersifat mendesak;</li>\r\n  <li>Sumber berita yang pertama adalah sumber yang jelas disebutkan identitasnya, kredibel dan kompeten;</li>\r\n  <li>Subyek berita yang harus dikonfirmasi tidak diketahui keberadaannya dan atau tidak dapat diwawancarai;</li>\r\n  <li>Media memberikan penjelasan kepada pembaca bahwa berita tersebut masih memerlukan verifikasi lebih lanjut yang diupayakan dalam waktu secepatnya. Penjelasan dimuat pada bagian akhir dari berita yang sama, di dalam kurung dan menggunakan huruf miring.</li>\r\n </ol>\r\n </li>\r\n <li>Setelah memuat berita sesuai dengan butir (c), media wajib meneruskan upaya verifikasi, dan setelah verifikasi didapatkan, hasil verifikasi dicantumkan pada berita pemutakhiran (update) dengan tautan pada berita yang belum terverifikasi.</li>\r\n</ol>\r\n\r\n<p><br>\r\n<strong>3. Isi Buatan Pengguna (User Generated Content)</strong></p>\r\n\r\n<ol>\r\n <li>Media siber wajib mencantumkan syarat dan ketentuan mengenai Isi Buatan Pengguna yang tidak bertentangan dengan Undang-Undang No. 40 tahun 1999 tentang Pers dan Kode Etik Jurnalistik, yang ditempatkan secara terang dan jelas.</li>\r\n <li>Media siber mewajibkan setiap pengguna untuk melakukan registrasi keanggotaan dan melakukan proses log-in terlebih dahulu untuk dapat mempublikasikan semua bentuk Isi Buatan Pengguna. Ketentuan mengenai log-in akan diatur lebih lanjut.</li>\r\n <li>Dalam registrasi tersebut, media siber mewajibkan pengguna memberi persetujuan tertulis bahwa Isi Buatan Pengguna yang dipublikasikan:\r\n <ol>\r\n  <li>Tidak memuat isi bohong, fitnah, sadis dan cabul;</li>\r\n  <li>Tidak memuat isi yang mengandung prasangka dan kebencian terkait dengan suku, agama, ras, dan antargolongan (SARA), serta menganjurkan tindakan kekerasan;</li>\r\n  <li>Tidak memuat isi diskriminatif atas dasar perbedaan jenis kelamin dan bahasa, serta tidak merendahkan martabat orang lemah, miskin, sakit, cacat jiwa, atau cacat jasmani.</li>\r\n </ol>\r\n </li>\r\n <li>Media siber memiliki kewenangan mutlak untuk mengedit atau menghapus Isi Buatan Pengguna yang bertentangan dengan butir (c).</li>\r\n <li>Media siber wajib menyediakan mekanisme pengaduan Isi Buatan Pengguna yang dinilai melanggar ketentuan pada butir (c). Mekanisme tersebut harus disediakan di tempat yang dengan mudah dapat diakses pengguna.</li>\r\n <li>Media siber wajib menyunting, menghapus, dan melakukan tindakan koreksi setiap Isi Buatan Pengguna yang dilaporkan dan melanggar ketentuan butir (c), sesegera mungkin secara proporsional selambat-lambatnya 2 x 24 jam setelah pengaduan diterima.</li>\r\n <li>Media siber yang telah memenuhi ketentuan pada butir (a), (b), (c), dan (f) tidak dibebani tanggung jawab atas masalah yang ditimbulkan akibat pemuatan isi yang melanggar ketentuan pada butir (c).</li>\r\n <li>Media siber bertanggung jawab atas Isi Buatan Pengguna yang dilaporkan bila tidak mengambil tindakan koreksi setelah batas waktu sebagaimana tersebut pada butir (f).</li>\r\n</ol>\r\n\r\n<p><br>\r\n<strong>4. Ralat, Koreksi, dan Hak Jawab</strong></p>\r\n\r\n<ol>\r\n <li>Ralat, koreksi, dan hak jawab mengacu pada Undang-Undang Pers, Kode Etik Jurnalistik, dan Pedoman Hak Jawab yang ditetapkan Dewan Pers.</li>\r\n <li>Ralat, koreksi dan atau hak jawab wajib ditautkan pada berita yang diralat, dikoreksi atau yang diberi hak jawab.</li>\r\n <li>Di setiap berita ralat, koreksi, dan hak jawab wajib dicantumkan waktu pemuatan ralat, koreksi, dan atau hak jawab tersebut.</li>\r\n <li>Bila suatu berita media siber tertentu disebarluaskan media siber lain, maka:\r\n <ol>\r\n  <li>Tanggung jawab media siber pembuat berita terbatas pada berita yang dipublikasikan di media siber tersebut atau media siber yang berada di bawah otoritas teknisnya;</li>\r\n  <li>Koreksi berita yang dilakukan oleh sebuah media siber, juga harus dilakukan oleh media siber lain yang mengutip berita dari media siber yang dikoreksi itu;</li>\r\n  <li>Media yang menyebarluaskan berita dari sebuah media siber dan tidak melakukan koreksi atas berita sesuai yang dilakukan oleh media siber pemilik dan atau pembuat berita tersebut, bertanggung jawab penuh atas semua akibat hukum dari berita yang tidak dikoreksinya itu.</li>\r\n </ol>\r\n </li>\r\n <li>Sesuai dengan Undang-Undang Pers, media siber yang tidak melayani hak jawab dapat dijatuhi sanksi hukum pidana denda paling banyak Rp500.000.000 (Lima ratus juta rupiah).</li>\r\n</ol>\r\n\r\n<p><br>\r\n<strong>5. Pencabutan Berita</strong></p>\r\n\r\n<ol>\r\n <li>Berita yang sudah dipublikasikan tidak dapat dicabut karena alasan penyensoran dari pihak luar redaksi, kecuali terkait masalah SARA, kesusilaan, masa depan anak, pengalaman traumatik korban atau berdasarkan pertimbangan khusus lain yang ditetapkan Dewan Pers.</li>\r\n <li>Media siber lain wajib mengikuti pencabutan kutipan berita dari media asal yang telah dicabut.</li>\r\n <li>Pencabutan berita wajib disertai dengan alasan pencabutan dan diumumkan kepada publik.</li>\r\n</ol>\r\n\r\n<p><br>\r\n<strong>6. Iklan</strong></p>\r\n\r\n<ol>\r\n <li>Media siber wajib membedakan dengan tegas antara produk berita dan iklan.</li>\r\n <li>Setiap berita/artikel/isi yang merupakan iklan dan atau isi berbayar wajib mencantumkan keterangan</li>\r\n</ol>\r\n\r\n<p> </p>\r\n', '2022-01-01 16:06:19', '2022-01-01 16:06:19', 0, '0c95dc79a6941af4988078277409ac1c.jpg', 0);
INSERT INTO `page` (`id_page`, `judul`, `judul_seo`, `isi`, `create_date`, `update_date`, `pub`, `photo`, `status`) VALUES (9, 'About Us', 'about-us', '<p><strong>ABOUT US</strong></p>\r\n', '2022-01-01 16:06:19', '2022-01-01 16:06:19', 0, '', 0);
INSERT INTO `page` (`id_page`, `judul`, `judul_seo`, `isi`, `create_date`, `update_date`, `pub`, `photo`, `status`) VALUES (7, 'Info Iklan', 'info-iklan', '<p><strong>INFO IKLAN</strong></p>\r\n', '2022-01-01 16:06:19', '2022-01-01 16:06:19', 0, '/upload/images/page/360_200.jpg#', 1);
INSERT INTO `page` (`id_page`, `judul`, `judul_seo`, `isi`, `create_date`, `update_date`, `pub`, `photo`, `status`) VALUES (8, 'Redaksi', 'redaksi', '<table class=\"tg\">\r\n <tbody>\r\n  <tr>\r\n   <th xss=removed><strong>PENANGGUNG JAWAB REDAKSI</strong></th>\r\n   <th><strong>:</strong></th>\r\n   <th xss=removed> </th>\r\n  </tr>\r\n  <tr>\r\n   <td><strong>PRODUCER</strong></td>\r\n   <td><strong>:</strong></td>\r\n   <td> </td>\r\n  </tr>\r\n  <tr>\r\n   <td><strong>MANAGER NEWS GATHERING & DEVELOPMENT</strong></td>\r\n   <td><strong>:</strong></td>\r\n   <td> </td>\r\n  </tr>\r\n  <tr>\r\n   <td><strong>BOARD OF PRODUCER NEWS / PROGRAM</strong></td>\r\n   <td><strong>:</strong></td>\r\n   <td> </td>\r\n  </tr>\r\n  <tr>\r\n   <td><strong>SEKRETARIS REDAKSI</strong></td>\r\n   <td><strong>:</strong></td>\r\n   <td> </td>\r\n  </tr>\r\n  <tr>\r\n   <td><strong>DIRECTOR OF SALES & MARKETING</strong></td>\r\n   <td><strong>:</strong></td>\r\n   <td> </td>\r\n  </tr>\r\n  <tr>\r\n   <td><strong>MANAGER SOCIAL MEDIA & DIGITAL</strong></td>\r\n   <td><strong>:</strong></td>\r\n   <td> </td>\r\n  </tr>\r\n  <tr>\r\n   <td><strong>HEAD OF CAMERA PERSON</strong></td>\r\n   <td><strong>:</strong></td>\r\n   <td> </td>\r\n  </tr>\r\n </tbody>\r\n</table>\r\n\r\n<p><strong>Alamat Redaksi & Sales<br>\r\n<br>\r\nEmail Redaksi : -<br>\r\nEmail Sales : -</strong></p>\r\n\r\n<p> </p>\r\n\r\n<p> </p>\r\n', '2022-01-01 16:06:19', '2022-01-01 16:06:19', 0, '', 0);
INSERT INTO `page` (`id_page`, `judul`, `judul_seo`, `isi`, `create_date`, `update_date`, `pub`, `photo`, `status`) VALUES (10, 'DISCLAIMER', 'disclaimer', '<p><strong>DISCLAIMER</strong></p>\r\n\r\n<p>Seluruh layanan yang diberikan mengikuti aturan main yang berlaku dan ditetapkan oleh <strong>bantennetwork.co.id.</strong></p>\r\n\r\n<p><strong>Pasal Sanggahan (Disclaimer) :</strong></p>\r\n\r\n<p>bantennetwork.co.id tidak bertanggung-jawab atas tidak tersampaikannya data/informasi yang disampaikan oleh pembaca melalui berbagai jenis saluran komunikasi (e-mail, sms, online form) karena faktor kesalahan teknis yang tidak diduga-duga sebelumnya</p>\r\n\r\n<p>bantennetwork.co.id berhak untuk memuat , tidak memuat, mengedit, dan/atau menghapus data/informasi yang disampaikan oleh pembaca.</p>\r\n\r\n<p>Data dan/atau informasi yang tersedia di bantennetwork.co.id hanya sebagai rujukan/referensi belaka, dan tidak diharapkan untuk tujuan perdagangan saham, transaksi keuangan/bisnis maupun transaksi lainnya.</p>\r\n\r\n<p>Walau berbagai upaya telah dilakukan untuk menampilkan data dan/atau informasi seakurat mungkin, bantennetwork.co.id dan semua mitra yang menyediakan data dan informasi, termasuk para pengelola halaman konsultasi, tidak bertanggung jawab atas segala kesalahan dan keterlambatan memperbarui data atau informasi, atau segala kerugian yang timbul karena tindakan yang berkaitan dengan penggunaan data/informasi yang disajikan <strong>bantennetwork.co.id.</strong></p>\r\n\r\n<p><strong>Kebijakan Konten Dewasa</strong></p>\r\n\r\n<p>Kebijakan ini mengatur semua konten dewasa yang terbit di bantennetwork.co.id. Artikel yang mengandung konten dewasa adalah yang memuat tentang organ-organ genital dan mengandung unsur seksualitas. Untuk bisa mengakses konten dewasa bantennetwork.co.id, maka pembaca harus berusia 18 tahun ke atas.</p>\r\n', '2022-01-01 16:06:19', '2022-01-01 16:06:19', 0, '', 1);
INSERT INTO `page` (`id_page`, `judul`, `judul_seo`, `isi`, `create_date`, `update_date`, `pub`, `photo`, `status`) VALUES (11, 'COPYRIGHT', 'copyright', '<p><strong>COPYRIGHT</strong></p>\r\n\r\n<p>Seluruh materi artikel/berita (teks, foto, video, logo) yang terdapat dalam seluruh situs bantennetwork.co.id dilindungi undang-undang hak cipta. Seluruh materi tersebut bebas dimanfaatkan oleh individu untuk keperluan referensi dan non-komersial.</p>\r\n\r\n<p>Bagi siapa saja yang bermaksud memanfaatkan materi bantennetwork.co.id dengan cara memproduksi ulang, mengutip, menyadur, memperbanyak dan/atau menyebarluaskan sebagian atau keseluruhan dari isi materi tersebut, diharuskan memenuhi ketentuan-ketentuan sebagai berikut:</p>\r\n\r\n<p>Pemanfaatan materi untuk keperluan pendidikan, penelitian, kajian non-komersial dan konsumsi individual seperti mailing-list, blog dan forum komunitas, tidak harus mendapatkan izin dari bantennetwork.co.id, namun tetap disarankan untuk menyampaikan pemberitahuan guna menghindari penyalahgunaan materi terkait.</p>\r\n\r\n<p>Pemanfaatan materi selain hal di atas harus mendapatkan izin dari bantennetwork.co.id.</p>\r\n\r\n<p>Pemanfaatan materi wajib mencantumkan sekurang-kurangnya kata-kata.</p>\r\n', '2022-01-01 16:06:19', '2022-01-01 16:06:19', 0, '', 0);


#
# TABLE STRUCTURE FOR: plugin
#

DROP TABLE IF EXISTS `plugin`;

CREATE TABLE `plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  `url` varchar(50) NOT NULL,
  `plugin_arr` tinytext NOT NULL,
  `pub` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `plugin` (`id`, `nama`, `url`, `plugin_arr`, `pub`) VALUES (1, 'Facebook', 'komentar', '{\"pages\":\"12345\",\"site_name\":\"lenteranews.tv\",\"app_id\":\"218316348502201\"}', 0);
INSERT INTO `plugin` (`id`, `nama`, `url`, `plugin_arr`, `pub`) VALUES (2, 'Google Custom Search', 'pencarian', '{\"partnerid\":\"partneridz\"}', 1);
INSERT INTO `plugin` (`id`, `nama`, `url`, `plugin_arr`, `pub`) VALUES (3, 'Google Analytic', 'analytic', '{\"partnerid\":\"UA-71802394-1\"}', 0);
INSERT INTO `plugin` (`id`, `nama`, `url`, `plugin_arr`, `pub`) VALUES (4, 'Google MAP', 'map', '{\"embed\":\"https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d31736.377631867526!2d106.167644!3d-6.12435!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x16f9d4f3c57b6fba!2ssayuti.com!5e0!3m2!1sen!2sid!4v1537786091492\"}', 0);
INSERT INTO `plugin` (`id`, `nama`, `url`, `plugin_arr`, `pub`) VALUES (5, 'Twitter', 'tw', '{\"site\":\"lenteranews.tv\",\"creator\":\"@lenteranews.tv\",\"domain\":\"www.lenteranews.tv\"}', 0);


#
# TABLE STRUCTURE FOR: populer
#

DROP TABLE IF EXISTS `populer`;

CREATE TABLE `populer` (
  `id_populer` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `id_cat` int(11) NOT NULL,
  `jenis` int(11) NOT NULL,
  `klik` int(11) NOT NULL,
  `tanggalklik` date NOT NULL,
  `tgl_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_populer`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `populer` (`id_populer`, `id_post`, `id_cat`, `jenis`, `klik`, `tanggalklik`, `tgl_update`) VALUES (1, 1, 1, 0, 6, '2022-01-01', '2022-01-01 18:38:55');
INSERT INTO `populer` (`id_populer`, `id_post`, `id_cat`, `jenis`, `klik`, `tanggalklik`, `tgl_update`) VALUES (2, 2, 10, 0, 1, '2022-01-01', '2022-01-01 05:50:46');
INSERT INTO `populer` (`id_populer`, `id_post`, `id_cat`, `jenis`, `klik`, `tanggalklik`, `tgl_update`) VALUES (3, 4, 2, 0, 5, '2022-01-01', '2022-01-01 09:49:12');
INSERT INTO `populer` (`id_populer`, `id_post`, `id_cat`, `jenis`, `klik`, `tanggalklik`, `tgl_update`) VALUES (4, 3, 1, 0, 13, '2022-01-01', '2022-01-01 23:06:31');
INSERT INTO `populer` (`id_populer`, `id_post`, `id_cat`, `jenis`, `klik`, `tanggalklik`, `tgl_update`) VALUES (5, 5, 10, 0, 10, '2022-01-01', '2022-01-01 16:14:55');


#
# TABLE STRUCTURE FOR: posting
#

DROP TABLE IF EXISTS `posting`;

CREATE TABLE `posting` (
  `id_post` int(11) NOT NULL AUTO_INCREMENT,
  `id_cat` int(11) DEFAULT NULL,
  `alias` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_publisher` int(11) DEFAULT 0,
  `judul` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `judul_seo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `publish` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `postingan` text COLLATE utf8_unicode_ci NOT NULL,
  `kata_kunci` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `tanggal` datetime NOT NULL,
  `dateModified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `folder` datetime NOT NULL,
  `gambar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `youtube` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `durasi` time DEFAULT NULL,
  `caption` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `dibaca` int(11) NOT NULL DEFAULT 1,
  `count` int(11) DEFAULT NULL,
  `tag` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `label` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_post`),
  FULLTEXT KEY `judul` (`judul`),
  FULLTEXT KEY `judul_2` (`judul`,`postingan`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `posting` (`id_post`, `id_cat`, `alias`, `id_publisher`, `judul`, `judul_seo`, `publish`, `postingan`, `kata_kunci`, `deskripsi`, `status`, `tanggal`, `dateModified`, `folder`, `gambar`, `youtube`, `durasi`, `caption`, `dibaca`, `count`, `tag`, `label`) VALUES (1, 1, NULL, 2, 'Lorem Ipsum adalah contoh teks atau dummy dalam industri percetakan', 'lorem-ipsum-adalah-contoh-teks-atau-dummy-dalam-industri-percetakan', 'Y', '<p><strong>Lorem Ipsum</strong> adalah contoh teks atau dummy dalam industri percetakan dan penataan huruf atau typesetting. Lorem Ipsum telah menjadi standar contoh teks sejak tahun 1500an, saat seorang tukang cetak yang tidak dikenal mengambil sebuah kumpulan teks dan mengacaknya untuk menjadi sebuah buku contoh huruf. Ia tidak hanya bertahan selama 5 abad, tapi juga telah beralih ke penataan huruf elektronik, tanpa ada perubahan apapun. Ia mulai dipopulerkan pada tahun 1960 dengan diluncurkannya lembaran-lembaran Letraset yang menggunakan kalimat-kalimat dari Lorem Ipsum, dan seiring munculnya perangkat lunak Desktop Publishing seperti Aldus PageMaker juga memiliki versi Lorem Ipsum.</p>\r\n', NULL, NULL, 2, '2022-01-01 01:31:00', '2022-01-01 18:38:55', '2022-01-01 01:31:00', '9b23eb8df5af83c1f58fac2d13b5b552.jpg', '', '00:00:00', '', 7, NULL, NULL, 0);
INSERT INTO `posting` (`id_post`, `id_cat`, `alias`, `id_publisher`, `judul`, `judul_seo`, `publish`, `postingan`, `kata_kunci`, `deskripsi`, `status`, `tanggal`, `dateModified`, `folder`, `gambar`, `youtube`, `durasi`, `caption`, `dibaca`, `count`, `tag`, `label`) VALUES (4, 2, NULL, 2, 'Title: Kornas Jokowi Bersurat Ke Presiden, Pertanyakan Transparansi Pemecatan Kompol Yuni ', 'title-kornas-jokowi-bersurat-ke-presiden-pertanyakan-transparansi-pemecatan-kompol-yuni', 'Y', '<p><strong>Jakarta,BN</strong> - Kornas Jokowi mempertanyakan Pemberhentian Tidak Dengan Hormat (PTDH) Kompol Yuni Purwanti, dari institusi Polri. Lantaran, ketidak terbukaannya langkah pemberhentian mantan Kapolsek Astanaanyar itu.</p>\r\n\r\n<p>\"Kornas Jokowi meminta Polri untuk transparan membuka kasusnya,\" kata Abdul Havid Permana, Ketua Umum Kornas Jokowi, Kamis (30/12/2021).</p>\r\n\r\n<p>Abdul Havid Permana ajak bersurat dan mengadukan berbagai kejanggalan tersebut ke Presiden Jokowi, yang merupakan pembina para relawannya. Aduan dibuat agar institusi Polri bisa menjadi lebih baik lagi.</p>\r\n\r\n<p>\"Kornas Jokowi juga akan secara resmi mengajukan pengaduan kepada Presiden sebagai pembina para relawan Jokowi,\" terangnya.</p>\r\n\r\n<p>Menurutnya ada beberapa kejanggalan dalam penanganan kasus Kompol Yuni, umumnya PTDH diumumkan  ke media setelah yang bersangkutan menerima surat legalitas pemecatan. Namun Propam Polda Jabar mengumumkannya tidak berdasarkan surat yang jelas atau biasanya melalui Telegram Rahasia (TR). Kemudian berita PTDH Kompol Yuni diangkat melalui berbagai media massa.</p>\r\n\r\n<p>Transparansi Polri sangat penting untuk menjaga marwah dan citra baik institusi Bhayangkara. Sehingga, berbagai langkah yang sudah ditempuh harus dibuka ke publik.</p>\r\n\r\n<p>\"Jangan sampai citra Polri tercoreng sebagai garda terdepan pemberantasan mafia kasus justru berbuat sebaliknya,\" ujarnya.(red)</p>\r\n', NULL, NULL, 2, '2021-12-30 05:58:00', '2022-01-01 09:49:12', '2022-01-01 05:58:00', 'e35c54f4fcd1020855550bb641520b07.jpg', '', '00:00:00', 'Kompol Yuni Purwanti', 6, NULL, '', 0);
INSERT INTO `posting` (`id_post`, `id_cat`, `alias`, `id_publisher`, `judul`, `judul_seo`, `publish`, `postingan`, `kata_kunci`, `deskripsi`, `status`, `tanggal`, `dateModified`, `folder`, `gambar`, `youtube`, `durasi`, `caption`, `dibaca`, `count`, `tag`, `label`) VALUES (3, 1, NULL, 2, 'Ekspor Banten Dongkrak Pertumbuhan Ekonomi Nasional Tahun 2021', 'ekspor-banten-dongkrak-pertumbuhan-ekonomi-nasional-tahun-2021', 'Y', '<p><strong>Serang,​​​​ BN</strong> - Gairah ekspor di Banten terus tumbuh pada tahun 2021. Beberapa produk yang diekspor di Banten di antaranya pertanian, kelautan dan produk lainnya. </p>\r\n\r\n<p>Kepala Dinas Perindustrian dan Perdagangan (Disperindag) Provinsi Banten, Babar Suharso, Jumat (31/12/2021) mengatakan, Banten telah beberapa kali melakukan ekspor.</p>\r\n\r\n<p>Catatan terakhir ini pada 31 Desember 2021 dilakukan secara serempak oleh Menteri Pertanian (Mentan) Syahrul Yasin Limpo yang melepaskan ekspor secara serempak di Pelabuhan Makassar.</p>\r\n\r\n<p>Kegiatan Gebyar Ekspor Pertanian ini mengangkat tema \"Ekspor Tangguh, Indonesia Tumbuh.\" Acara itu juga dihadiri Kapolri Jenderal Listyo Sigit Prabowo di Pelabuhan Soekarno Hatta, Makassar, Sulawesi Selatan, Jumat 31 Desember 2021.</p>\r\n\r\n<p>Mentan  Syahrul Yasin Limpo  melepas ekspor hasil pertanian dari 34 provinsi termasuk Provinsi Banten dengan nilai Rp14,4 triliun. Volumenya mencapai 1,3 juta ton ke 124 negara.</p>\r\n\r\n<p>Menurut Babar, Banten pada ekspor di ujung tahun 2021 ini mengekspor Sarang Burung Walet dan Manggis. </p>\r\n\r\n<p>\"Banyak produk pertanian yang di ekspor di Banten di antaranya bubuk kakao,\" ujarnya.</p>\r\n\r\n<p>Sebelumnya, di Provinsi Banten melakukan prosesi pelepasan ekspor yang dilaksanakan di dua lokasi pada 24 Desember 2021. Lokasi pertama PT. Polyplex Films Indonesia, di Kawasan Induatri Modern Cikande, Kabupaten Serang dan lokasi kedua yakni, PT. Prima Cooper Industri, di Jalan Kali Perancis Raya No.88, Dadap, Kecamatan Kosambi, Kabupaten Tangerang.</p>\r\n\r\n<p>Selain itu, Wakil Menteri Perdagangan (Wamendag), Jerry Sambuaga, menghadiri langsung pelepasan ekspor dari lokasi PT. Prima Cooper industri, didampingi oleh Irjen Kemendag Dodid Noordiatmoko, Kadisperindag Provinsi Banten Babar Suharso, dan Komisaris PT. Prima Cooper Industri Eric Wjaya.</p>\r\n\r\n<p>Di dua lokasi tersebut, juga pelepasan ekspor dilaksanakan oleh PT. Prima Mandala Makmur, Kabupaten Tangerang.</p>\r\n\r\n<p>Sebagaimana data visual yang ditayangkan oleh Kementerian Perdagangan (Kemendag) pada kesempatan tersebut, dari tiga perusahaan yang melakukan pelepasan ekspor pada Kamis 23 Desember 2021 di Provinsi Banten, tercatat nilai ekspor total sebesar 1,5 juta US Dollar atau setara Rp 21 miliar. </p>\r\n\r\n<p>Lebih lanjut, Babar menjelaskan, berdasarkan data dokumen ekspor yang sedang diproses oleh tiga perusahaan tersebut, tercatat bahwa nilai ekspor yang akan dilaksanakan selama bulan Desember 2021 adalah sebesar 7,4 juta US Dollar atau setara Rp105 miliar. </p>\r\n\r\n<p>Sebelumnya, kata Babar ekspor dari wilayah Banten ke sejumlah negara Asia, Eropa hingga Amerika mampu mendongkrak pertumbuhan ekonomi Banten, dari negatif menjadi positif. Setidaknya pada kuartal III 2021, tumbuh menjadi 4,62 persen.</p>\r\n\r\n<p>Nilai ekspor Banten pada Oktober 2021 senilai 1.117,69 juta USD. Nilai ekspor non migas senilai 1.113,26 juta USD, penyumbang terbesarnya dari alas kaki senilai 203,38 juta USD. Kemudian negara tujuan ekspor non migas terbesar ke Amerika, senilai 193,98 juta USD.</p>\r\n\r\n<p>\"Dengan nilai ekspor naik, itu ternyata meningkatkan laju perekonomian Banten, yang tadinya negatif jadi positif. Makanya saya lagi galak untuk pacu ekspor. Ini sinergi, ternyata Kementerian Pertanian, Kementerian Perdagangan, Kementerian Keuangan melalui bea cukai itu sedang menggenjot ekspor,\" kata Babar Suharso.</p>\r\n\r\n<p>Babar mengaku pihaknya membantu Industri Kecil Menengah (IKM) dan Usaha Mikro Kecil dan Menengah (UMKM) untuk menembus pasar ekspor, melalui pelatihan dan coaching export program yang dilakukan sejak Maret hingga Desember 2021. </p>\r\n\r\n<p>Ada 30 IKM dan UMKM yang mengikuti pelatihan, hasilnya ada 15 peserta yang bisa menembus pangsa pasar ekspor.</p>\r\n\r\n<p>Pelaku usaha kecil itu diberi pelatihan mengurus izin dokumen ekspor hingga dipertemukan dengan pembeli. Salah satunya usaha kecil pembuat bubuk dan minyak cokelat, yang tembus ke belasan negara.</p>\r\n\r\n<p>\"Bukan hanya teori, langsung ditemui dengan pembeli luar negeri, difasilitasi. Dibimbing cara menghadapi buyer, cara nego, cara transaksi, cara pembayaran yang terjamin dan aman segala macam, dikawal sama Kementerian Perdagangan (Kemendag) dan Kementerian Luar Negeri (Kemenlu),\" ujarnya.</p>\r\n\r\n<p>Pada 23 Desember 2021 Menteri Perdagangan (Mendag) Muhammad Lutfi yang diwakili Wakil Mendag Jerry Sambuaga memimpin pelepasan pasar ekspor senilai Rp35,03 triliun atau setara 2,44 miliar US Dollar.</p>\r\n\r\n<p>Dalam pelepasan ekspor ini, Wamendag Jerry Sambuaga menegaskan bahwa ekonomi nasional mulai pulih. Momentum ini harus terus dijaga secara serius agar perekonomian Indonesia bisa lebih cepat bangkit dan tumbuh. </p>\r\n\r\n<p>“Hari ini saya ekspor senilai Rp35,03 triliun secara serentak di 18 titik di 62 kabupaten/kota di 26 provinsi di Indonesia secara hibrida. Pelepasan ekspor ini merupakan kolaborasi dan kerja sama dari seluruh pemangku kepentingan, baik pemerintah pusat, pemerintah daerah maupun para pelaku usaha untuk mendorong pemulihan ekonomi nasional, serta meningkatkan kinerja ekspor nasional,\" ujar Wamendag Jerry Sambuaga.</p>\r\n\r\n<p>Jerry Sambuaga berharap pelepasan ekspor dapat memotivasi kalangan dunia usaha untuk terus mempertahankan dan memperluas pasar ekspornya.(Red)</p>\r\n', NULL, NULL, 2, '2021-12-31 05:45:00', '2022-01-01 23:06:31', '2022-01-01 05:45:00', '35d3ed55948b9ec2a8eec9af29785cee.jpg', '', '00:00:00', 'Kepala Dinas Perindustrian dan Perdagangan (Disperindag) Provinsi Banten, Babar Suharso (kanan) saat pelepasan ekspor akhir tahun 2021 oleh Menteri Perdagangan RI, Muhammad Lutfi, yang diwakili oleh Wakil Menteri Perdagangan (Wamendag), Jerry Sambuaga (ke', 14, NULL, 'ekonomi', 0);
INSERT INTO `posting` (`id_post`, `id_cat`, `alias`, `id_publisher`, `judul`, `judul_seo`, `publish`, `postingan`, `kata_kunci`, `deskripsi`, `status`, `tanggal`, `dateModified`, `folder`, `gambar`, `youtube`, `durasi`, `caption`, `dibaca`, `count`, `tag`, `label`) VALUES (5, 10, NULL, 2, ' Tidak Perlu Obat \'Kuat\' Inilah 10 Tips Tahan Lama Ala dr Boyke', '10-tips-tahan-lama-ala-dr-boyke-tidak-perlu-obat-kuat', 'Y', '<p><strong>Serang, BN</strong> - Tips tahan lama ala dr Boyke sebaiknya diketahui oleh kaum pria terutama yang kerap ejakulasi dini. Hubungan intim adalah kunci untuk menjaga keharmonisan dalam menjalin rumah tangga. Tapi, sayangnya masih belum banyak yang mengetahui tentang cara berhubungan intim yang benar. Alhasil, hubungan intim tidak berlangsung lama. Karena itu, kaum pria banyak yang meneguk obat kuat sebagai cara untuk berhubungan seksual tahan lama, tapi hal ini perlu dipikir ulang. Sebab, produk kejantanan yang dijual di pasaran ini dapat mengakibatkan berbagai penyakit, seperti jantung sampai kematian.</p>\r\n\r\n<p>Dokter Boyke merupakan salah seorang seksolog tersohor di Tanah Air. Menurutnya, banyak pria yang menggunakan obat kuat supaya bisa bertahan lama di ranjang yang tidak tahu efek samping yang ditimbulkan oleh obat tersebut. Maka dari itu, ia juga mengimbau untuk para produsen obat kuat supaya membekali pengetahuan kepada para konsumen mengenai efek samping yang ditimbulkan. Hal ini cukup penting sebagai upaya untuk mengantisipasi pemakaian obat kuat ini. Selain itu, seksolog kawakan yang kerap nongol di layar kaca ini juga memberikan berbagai tips tahan lama ala dr Boyke supaya dapat menghindari obat kuat, tapi tetap bisa memuaskan pasangan.</p>\r\n\r\n<p>Lantas, Bagaimana Tips Tahan Lama ala dr Boyke?</p>\r\n\r\n<p>1. Persiapkan dengan baik</p>\r\n\r\n<p>Tips tahan lama ala dr Boyke pertama adalah mempersiapkan berbagai kebutuhan dengan baik. Bila kamu dan pasangan masih malu-malu, maka bicarakan dengan baik-baik niat kamu. Karena, kamu juga tidak dapat memaksa pasangan walaupun sudah sah untuk melakukan hubungan suami istri. Lalu, bila kamu dan juga pasangan masih belum menginginkan buah hati, maka persiapkan alat kontrasepsi seperti kondom.</p>\r\n\r\n<p>2. Perhatikan Waktu</p>\r\n\r\n<p>Dalam berhubungan intim untuk pertama kalinya, tentu kamu menginginkan waktu yang panjang. Karena, waktu yang panjang ini akan memberikan kamu perasaan leluasa dan santai. Oleh sebab itu, perhatikan waktu untuk melakukan hubungan suami istri. Bila kamu tidak mau terburu-buru, tentunya kamu dapat melakukan ini di waktu malam yang panjang atau ketika bulan madu yang santai.</p>\r\n\r\n<p>3. Lakukan Senam Kegel</p>\r\n\r\n<p>Tips tahan lama ala dr Boyke berikutnya adalah dengan melakukan senam kegel. Hal ini dilakukan supaya meminimalisir cairan pria keluar dengan cepat. Seorang pria juga dapat melakukan jepit tahan. Cara tersebut, kata Boyke, juga memiliki manfaat untuk melatih otot pria, sehingga bisa menahan kapan harus keluar.</p>\r\n\r\n<p>4. Pilih Lokasi</p>\r\n\r\n<p>Tips berikutnya adalah dengan memilih lokasi yang mendukung dan juga romantis. Kamu dapat memilih suaasan gunung yang dingin dan sejuk, atau kamu juga bisa memilih suasana pantai yang sangat menyenangkan. Kamu juga perlu memperhatikan tempat tidur yang akan dipakai, pastikan untuk selalu bersih dan empuk.</p>\r\n\r\n<p>5. Ciptakan Suasana Mendukung</p>\r\n\r\n<p>Sesudah mempersiapkan lokasi, tips tahan lama ala dr Boyke adalah dengan menciptakan suasana yang mendukung. Dengan kata lain, buatlah suasana yang romantis dengan pasangan. Ajak pasangan kamu untuk berbicara dengan mesra, tatap matanya, dan lakukanlah gerakan yang mengundang.</p>\r\n\r\n<p>6. Banjiri dengan Ciuman</p>\r\n\r\n<p>Cara ini sangat penting untuk membuat kamu dan pasangan nyaman. Tips tahan lama ala dr Boyke ini tentunya harus diawali dengan ciuman yang lembut. Ketika suasana mulai memanas, tambahkan dengan sentuhan dan tingkatkan intensitas ciuman yang semakin membara.</p>\r\n\r\n<p>7. Lakukan Foreplay</p>\r\n\r\n<p>Dokter Boyke Dian Nugraha juga menyarankan untuk kaum adam supaya melakukan foreplay yang baik dan benar pada pasangannya supaya cepat mencapai orgasme. Selain itu, Boyke juga menuturkan bahwa laki-laki harus melakukan rangsangan pada titik-titik yang sensitif pada pasangan kita. Karena, kegagalan untuk memberikan orgasme pada pasangan dapat menjadi salah satu motivasi laki-laki untuk mengonsumsi obat kuat.</p>\r\n\r\n<p>8. Banyak Mencoba Posisi</p>\r\n\r\n<p>Sesudah kamu menguasai keadaan, coba untuk mencoba berkreasi posisi seks. Terdapat berbagai posisi seks yang bisa menjadi referensi kamu untuk melakukan hubungan intim dengan pasangan. Selain posisi klasik misionari, kamu juga bisa mencoba posisi lain seperti spooning, woman on top, doggy style, sampai 69. Lakukanlah semaksimal mungkin serta pilih posisi yang nyaman antara kamu dan pasangan agar bisa mendapatkan orgasme.</p>\r\n\r\n<p>9. Maksimalkan Penetrasi</p>\r\n\r\n<p>Dengan melakukan foreplay yang panjang, tentu saja kamu akan mempunyai keinginan untuk melakukan ke tahap berikutnya, yaitu penetrasi. Laki-laki, lakukan ini secara perlahan dengan penuh kelembutan. Karena, bila penetrasi dengan terburu-buru akan membuat pasangan kesakitan. Selain itu, pilihlah posisi yang baik untuk melakukan penetrasi. Karena, posisi yang salah bisa membuat wanita kesakitan atau malu.</p>\r\n\r\n<p>10. Lakukan After Sex</p>\r\n\r\n<p>Sesudah kamu ejakulasi dan pasangan orgasme, jangan lupa untuk melakukan kegiatan after sex atau setelah berhubungan badan. Sebab, wanita merupakan makhluk yang sangat suka disayang, kamu bisa mengecup, memeluk, membisikkan kata-kata romantis walaupun kamu sudah merasa lelah. Kegiatan ini menjadi sebuah cara untuk melakukan hubungan intim yang baik dan benar serta membahagiakan masing-masing.(Red)</p>\r\n\r\n<p>sumber viva.co.id</p>\r\n\r\n<p> </p>\r\n\r\n<p> </p>\r\n\r\n<p> </p>\r\n', NULL, NULL, 2, '2022-01-01 07:08:00', '2022-01-01 16:14:55', '2022-01-01 07:08:00', 'fe583dbbe465e1a9981020b927a14534.jpg', '', '00:00:00', 'Ilustrasi', 11, NULL, '', 0);


#
# TABLE STRUCTURE FOR: setting
#

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO `setting` (`id`, `name`, `value`) VALUES (1, 'site_theme', 'default');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (2, 'admin_theme', 'fiyo');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (3, 'site_name', 'bantennetwork.co.id');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (4, 'site_keys', 'berita banten, berita terkini');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (5, 'site_desc', 'Banten Network');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (6, 'site_title', 'Banten Banten Terkini ');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (7, 'site_url', 'https://bantennetwork.co.id');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (8, 'site_company', 'PT. Banten Network');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (9, 'sef_url', '1');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (10, 'file_allowed', 'swf flv avi mpg mpeg qt mov wmv asf rm rar zip exe msi iso');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (11, 'file_size', '5120');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (12, 'media_theme', 'dark');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (13, 'title_type', '1');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (14, 'title_divider', '-');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (15, 'sef_www', '1');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (16, 'site_phone', '081269991777');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (17, 'site_mail', 'bantennetwork.co.id@gmail.com');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (18, 'backend_folder', 'dapur');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (19, 'follow_link', '1');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (20, 'member_registration', '0');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (21, 'member_activation', '2');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (22, 'member_group', '5');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (23, 'version', '2.0.6');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (24, 'lang', 'id');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (25, 'timezone', 'Asia/Jakarta');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (26, 'api_key', '500');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (27, 'disk_space', '500');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (28, 'site_favicon', 'ab93ef8ee55b0a120a848d339e71fbdb.png');
INSERT INTO `setting` (`id`, `name`, `value`) VALUES (29, 'site_logo', '1671695ef85d9ff6e9a8a5849293198d.png');


#
# TABLE STRUCTURE FOR: sosmed
#

DROP TABLE IF EXISTS `sosmed`;

CREATE TABLE `sosmed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `idkey` varchar(100) NOT NULL,
  `publish` enum('Y','N') NOT NULL DEFAULT 'Y',
  `tag` varchar(20) NOT NULL,
  `urutan` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `sosmed` (`id`, `judul`, `link`, `idkey`, `publish`, `tag`, `urutan`) VALUES (1, 'Twitter', 'https://twitter.com/bantennetwork', 'twitter', 'Y', 'TW', 1);
INSERT INTO `sosmed` (`id`, `judul`, `link`, `idkey`, `publish`, `tag`, `urutan`) VALUES (2, 'Facebook', 'https://www.facebook.com/bantennetwork', 'facebook', 'Y', 'FB', 2);
INSERT INTO `sosmed` (`id`, `judul`, `link`, `idkey`, `publish`, `tag`, `urutan`) VALUES (3, 'Instagram', 'https://www.instagram.com/bantennetwork', 'instagram', 'Y', 'IG', 3);
INSERT INTO `sosmed` (`id`, `judul`, `link`, `idkey`, `publish`, `tag`, `urutan`) VALUES (4, 'Telegram', '#', 'telegram', 'Y', 'TL', 4);


#
# TABLE STRUCTURE FOR: tag
#

DROP TABLE IF EXISTS `tag`;

CREATE TABLE `tag` (
  `id_tag` int(11) NOT NULL AUTO_INCREMENT,
  `nama_tag` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `tag_seo` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_tag`)
) ENGINE=MyISAM AUTO_INCREMENT=196 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (1, 'POLRES SERANG KOTA', 1, 'polres-serang-kota', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (2, 'PANDEGLANG', 1, 'pandeglang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (3, 'KOTA SERANG', 1, 'kota-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (4, 'BNN BANTEN', 1, 'bnn-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (5, 'PILPRES2019', 1, 'pilpres2019', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (6, 'CILEGON', 1, 'cilegon', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (7, 'BANTEN', 1, 'banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (8, 'TANGERANG', 1, 'tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (9, 'CISADANE', 1, 'cisadane', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (10, 'BURGERKILL', 1, 'burgerkill', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (11, 'LEBAK BANTEN', 1, 'lebak-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (12, 'POLRES PANDEGLANG', 1, 'polres-pandeglang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (13, 'KPU TANGERANG', 1, 'kpu-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (14, 'KPU KOTA SERANG', 1, 'kpu-kota-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (15, 'FLASHNEWS', 1, 'flashnews', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (16, 'MERAK', 1, 'merak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (17, 'PELABUHAN MERAK', 1, 'pelabuhan-merak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (18, 'KECELAKAAN KAPAL', 1, 'kecelakaan-kapal', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (19, 'LAKA LAUT MERAK BANTEN', 1, 'laka-laut-merak-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (20, 'POLRES LEBAK BANTEN', 1, 'polres-lebak-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (21, 'PARTAI PSI', 1, 'partai-psi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (22, 'WAGUB BANTEN', 1, 'wagub-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (23, 'PROVINSI BANTEN', 1, 'provinsi-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (24, 'BUPATI TANGERANG', 1, 'bupati-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (25, 'ZAKI ISKANDAR', 1, 'zaki-iskandar', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (26, 'KABUPATEN TANGERANG', 1, 'kabupaten-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (27, 'HARI BURUH 2019', 1, 'hari-buruh-2019', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (28, 'POLDA BANTEN', 1, 'polda-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (29, 'MENKUMHAM', 1, 'menkumham', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (30, 'MAFIA TANAH', 1, 'mafia-tanah', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (31, 'POLRESTA TANGERANG', 1, 'polresta-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (32, 'WISATA KABUPATEN TANGERANG', 1, 'wisata-kabupaten-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (33, 'PEMKAB TANGERANG', 1, 'pemkab-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (34, 'KOTA TANGERANG', 1, 'kota-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (35, 'MUDIK 2019', 1, 'mudik-2019', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (36, 'INFO MUDIK', 1, 'info-mudik', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (37, 'INFO MUDIK 2019', 1, 'info-mudik-2019', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (38, 'MUDIK LEBARAN 2019', 1, 'mudik-lebaran-2019', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (39, 'MERAK BANTEN', 1, 'merak-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (40, 'WAKAPOLRI', 1, 'wakapolri', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (41, 'ANI YUDHOYONO', 1, 'ani-yudhoyono', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (42, 'PANCASILA', 1, 'pancasila', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (43, 'HARI PANCASILA', 1, 'hari-pancasila', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (44, 'PRESIDEN RI', 1, 'presiden-ri', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (45, 'JOKO WIDODO', 1, 'joko-widodo', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (46, 'MUDIK GRATIS', 1, 'mudik-gratis', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (47, 'MAHKAMAH KONSTITUSI', 1, 'mahkamah-konstitusi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (48, 'CIGARU TANGERANG', 1, 'cigaru-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (49, 'WISATA BANTEN', 1, 'wisata-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (50, 'WISATA TANGERANG', 1, 'wisata-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (51, 'PERAMPOKAN BERSENJATA', 1, 'perampokan-bersenjata', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (52, 'PERAMPOKAN  EMAS BALARAJA', 1, 'perampokan-emas-balaraja', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (53, 'RUMAH DUNIA', 1, 'rumah-dunia', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (54, 'DIALOG PAGI', 1, 'dialog-pagi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (55, 'DANAU CIGARU CISOKA', 1, 'danau-cigaru-cisoka', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (56, 'POLRESTA TANEGRANG', 1, 'polresta-tanegrang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (57, 'PERISTIWA', 1, 'peristiwa', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (58, 'SERGAP', 1, 'sergap', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (59, 'TANGERANG BANTEN', 1, 'tangerang-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (60, 'MILLENNIAL ROAD SAFETY', 1, 'millennial-road-safety', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (61, 'MILLENNIAL ROAD SAFETY FESTIVAL', 1, 'millennial-road-safety-festival', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (62, 'POLRES SERANG', 1, 'polres-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (63, 'KABUPATEN SERANG', 1, 'kabupaten-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (64, 'POLRES TANGSEL', 1, 'polres-tangsel', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (65, 'WANITA MUDA TEWAS DI TANGAN TUNANGANYA', 1, 'wanita-muda-tewas-di-tangan-tunanganya', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (66, 'WAREONG SUNDA', 1, 'wareong-sunda', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (67, 'ZONA KULINER', 1, 'zona-kuliner', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (68, 'HUT BHAYANGKARA', 1, 'hut-bhayangkara', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (69, 'SAT LANTAS POLRESTA TANGERANG', 1, 'sat-lantas-polresta-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (70, 'PERSITIWA TANGERANG', 1, 'persitiwa-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (71, 'KRAKATAU STEEL', 1, 'krakatau-steel', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (72, 'DEMO BURUH', 1, 'demo-buruh', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (73, 'PEMBUNAHAN DI TANGERANG', 1, 'pembunahan-di-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (74, 'PEMBUNUHAN JAYANTI TANGERANG', 1, 'pembunuhan-jayanti-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (75, 'BURUH KRAKATU STEEL DEMO TOLAK PHK', 1, 'buruh-krakatu-steel-demo-tolak-phk', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (76, 'SANISEK', 1, 'sanisek', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (77, 'PEREDARAN NARKOTIKA', 1, 'peredaran-narkotika', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (78, 'PELAKU PEMBUNUHAN', 1, 'pelaku-pembunuhan', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (79, 'RAZIA PAJAK KENDARAAN', 1, 'razia-pajak-kendaraan', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (80, 'RAZIA KENDARAAN PAJAK', 1, 'razia-kendaraan-pajak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (81, 'WERWER', 1, 'werwer', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (82, 'RAZIA KENDARAAN', 1, 'razia-kendaraan', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (83, 'RAZIA KEBDARAAN PAJAK', 1, 'razia-kebdaraan-pajak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (84, 'KECAMATAN KELAPA DUA', 1, 'kecamatan-kelapa-dua', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (85, 'SEJUMLAH KENDARAAN DI LEBAK TERJARING RAZIA PAJAK', 1, 'sejumlah-kendaraan-di-lebak-terjaring-razia-pajak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (86, 'HARI ANTI NARKOBA INTERNASIONAL', 1, 'hari-anti-narkoba-internasional', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (87, 'PEMUSNAHAN NARKOTIKA', 1, 'pemusnahan-narkotika', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (88, 'HEWAN QURBAN', 1, 'hewan-qurban', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (89, 'GEMPA BANTEN', 1, 'gempa-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (90, 'TANGSEL', 1, 'tangsel', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (91, 'TANGERANG SELATAN', 1, 'tangerang-selatan', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (92, 'TNI POLRI', 1, 'tni-polri', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (93, 'RANGKASBITUNG', 1, 'rangkasbitung', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (94, 'LAPAS', 1, 'lapas', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (95, 'LEBAK', 1, 'lebak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (96, 'GUBERNUR BANTEN', 1, 'gubernur-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (97, 'ANDIKA HAZRUMY', 1, 'andika-hazrumy', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (98, 'BUPATI SERANG', 1, 'bupati-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (99, 'TATU CHASANAH', 1, 'tatu-chasanah', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (100, 'LAPAS RANGKASBITUNG', 1, 'lapas-rangkasbitung', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (101, 'HUT RI', 1, 'hut-ri', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (102, 'SUPER INDO', 1, 'super-indo', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (103, 'PEMPROV BANTEN', 1, 'pemprov-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (104, 'PILKADA PANDEGLANG', 1, 'pilkada-pandeglang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (105, 'BANK BANTEN', 1, 'bank-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (106, 'VIRUS CORONA', 1, 'virus-corona', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (107, 'DINAS KELAUTAN DAN PERIKANAN BANTEN', 1, 'dinas-kelautan-dan-perikanan-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (108, 'KOTA CILEGO', 1, 'kota-cilego', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (109, 'COVID 19', 1, 'covid-19', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (110, 'KOTA CILEGON', 1, 'kota-cilegon', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (111, 'HUT KOTA SERANG', 1, 'hut-kota-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (112, 'PILKADA CILEGON', 1, 'pilkada-cilegon', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (113, 'PILKADA SERANG', 1, 'pilkada-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (114, 'PILKADA', 1, 'pilkada', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (115, 'NELAYAN BANTEN', 1, 'nelayan-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (116, 'OMBUDSMAN RI', 1, 'ombudsman-ri', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (117, 'MERCEDES BENZ', 1, 'mercedes-benz', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (118, 'PILKADA KOTA CILEGON', 1, 'pilkada-kota-cilegon', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (119, 'BERITA', 1, 'berita', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (120, 'PSBB BANTEN', 1, 'psbb-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (121, 'PILKADA BANTEN', 1, 'pilkada-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (122, 'KEMENTRIAN KKP', 1, 'kementrian-kkp', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (123, 'WALIKOTA TANGSEL', 1, 'walikota-tangsel', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (124, 'AIRIN RACHMI', 1, 'airin-rachmi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (125, 'GARDU PINTAR', 1, 'gardu-pintar', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (126, 'PSBB', 1, 'psbb', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (127, 'WALIKOTA SERANG', 1, 'walikota-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (128, 'ADDE ROSI KHOERUNNISA', 1, 'adde-rosi-khoerunnisa', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (129, 'DPR RI', 1, 'dpr-ri', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (130, 'SYAFRUDIN', 1, 'syafrudin', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (131, 'MAAULID NABI', 1, 'maaulid-nabi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (132, 'CILEGON BANJIR', 1, 'cilegon-banjir', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (133, 'BERITA BANTEN', 1, 'berita-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (134, 'KAPOLSEK DICOPOT', 1, 'kapolsek-dicopot', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (135, 'KAPOLRES SERANG KOTA', 1, 'kapolres-serang-kota', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (136, 'PELABUHAN BINUANGEUN', 1, 'pelabuhan-binuangeun', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (137, 'WAHIDIN HALIM', 1, 'wahidin-halim', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (138, 'PILAR SAGA ICHSAN', 1, 'pilar-saga-ichsan', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (139, 'WAKIL WALIKOTA TANGSEL', 1, 'wakil-walikota-tangsel', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (140, 'KORUPSI DANA PONPES', 1, 'korupsi-dana-ponpes', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (141, 'KEJATI BANTEN', 1, 'kejati-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (142, 'CAFE MERESAHKAN', 1, 'cafe-meresahkan', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (143, 'SATPOL PP KOTA SERANG', 1, 'satpol-pp-kota-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (144, 'GEMPA BUMI', 1, 'gempa-bumi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (145, 'OPERASI KRYD', 1, 'operasi-kryd', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (146, 'WAKIL GUBERNUR BANTEN', 1, 'wakil-gubernur-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (147, 'BPK RI', 1, 'bpk-ri', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (148, 'KORUPSI MASKER', 1, 'korupsi-masker', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (149, 'DINKES PROVINSI BANTEN', 1, 'dinkes-provinsi-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (150, 'PROSTITUSI ONLINE', 1, 'prostitusi-online', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (151, 'POLRES CILEGON', 1, 'polres-cilegon', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (152, 'GELOMBANG TINGGI', 1, 'gelombang-tinggi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (153, 'BMKG', 1, 'bmkg', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (154, 'KABUPATEN LEBAK', 1, 'kabupaten-lebak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (155, 'PEMKOT SERANG', 1, 'pemkot-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (156, 'PANTAI SAWARNA', 1, 'pantai-sawarna', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (157, 'PEMKAB LEBAK', 1, 'pemkab-lebak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (158, 'ITI OCTAVIA JAYABAYA', 1, 'iti-octavia-jayabaya', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (159, 'FESTIVAL HBN', 1, 'festival-hbn', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (160, 'DPRD LEBAK', 1, 'dprd-lebak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (161, 'GUNUNG KENCANA', 1, 'gunung-kencana', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (162, 'PEMBKAB TANGERANG', 1, 'pembkab-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (163, 'SEKDA TANGERANG', 1, 'sekda-tangerang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (164, 'BAZNAS KABUPATEN SERANG', 1, 'baznas-kabupaten-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (165, 'KORUPSI', 1, 'korupsi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (166, 'LONGSOR', 1, 'longsor', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (167, 'GIANT SERANG', 1, 'giant-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (168, 'PEMUDA', 1, 'pemuda', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (169, 'PINJAMAN BUNGA NOL PERSEN', 1, 'pinjaman-bunga-nol-persen', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (170, 'BKD BANTEN', 1, 'bkd-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (171, 'KORBAN TENGGELAM', 1, 'korban-tenggelam', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (172, 'PANTAI ANYER', 1, 'pantai-anyer', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (173, 'DINSOS BANTEN', 1, 'dinsos-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (174, 'KEJARI SERANG', 1, 'kejari-serang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (175, 'PEMKOT CILEGON', 1, 'pemkot-cilegon', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (176, 'TAMBANG PASIR', 1, 'tambang-pasir', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (177, 'PENDIDIKAN', 1, 'pendidikan', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (178, 'PANDEMI COVID 19', 1, 'pandemi-covid-19', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (179, 'DKP BANTEN', 1, 'dkp-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (180, 'BABY LOBSTER', 1, 'baby-lobster', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (181, 'TNI AL BANTEN', 1, 'tni-al-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (182, 'KRIMINAL', 1, 'kriminal', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (183, 'TOL TANGERANG MERAK', 1, 'tol-tangerang-merak', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (184, 'DPRD BANTEN', 1, 'dprd-banten', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (185, 'AKSI MAHASISWA', 1, 'aksi-mahasiswa', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (186, 'PEMKOT TANGSEL', 1, 'pemkot-tangsel', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (187, 'WISATA UJUNG KULON', 1, 'wisata-ujung-kulon', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (188, 'KABUPATEN PANDEGLANG', 1, 'kabupaten-pandeglang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (189, 'VAKSINISASI', 1, 'vaksinisasi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (190, 'DKP KCD SELATAN', 1, 'dkp-kcd-selatan', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (191, 'PEMKAB PANDEGLANG', 1, 'pemkab-pandeglang', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (192, 'BENYAMINE DAVNIE', 1, 'benyamine-davnie', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (193, 'WAH', 1, 'wah', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (194, 'EKONOMI', 1, 'ekonomi', 0);
INSERT INTO `tag` (`id_tag`, `nama_tag`, `type`, `tag_seo`, `count`) VALUES (195, 'PERTANIAN', 1, 'pertanian', 0);


#
# TABLE STRUCTURE FOR: themes
#

DROP TABLE IF EXISTS `themes`;

CREATE TABLE `themes` (
  `id_thm` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `folder` varchar(50) NOT NULL,
  `publish` enum('Y','N','M') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_thm`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `themes` (`id_thm`, `nama`, `folder`, `publish`) VALUES (1, 'Template Baru', 'themes/frontend', 'Y');
INSERT INTO `themes` (`id_thm`, `nama`, `folder`, `publish`) VALUES (2, 'Template Admin', 'themes/admin', 'N');
INSERT INTO `themes` (`id_thm`, `nama`, `folder`, `publish`) VALUES (3, 'Template Mobile', 'themes/mobile', 'M');


#
# TABLE STRUCTURE FOR: widget
#

DROP TABLE IF EXISTS `widget`;

CREATE TABLE `widget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `id_cat` int(11) NOT NULL DEFAULT 0,
  `posisi` int(11) NOT NULL DEFAULT 1 COMMENT '1: kiri, 2 : kanan',
  `name` varchar(20) DEFAULT NULL,
  `jml` int(11) NOT NULL DEFAULT 0,
  `urutan` int(11) NOT NULL DEFAULT 0,
  `pub` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `widget` (`id`, `title`, `id_cat`, `posisi`, `name`, `jml`, `urutan`, `pub`) VALUES (1, 'Pemerintahan', 1, 1, NULL, 2, 1, 0);
INSERT INTO `widget` (`id`, `title`, `id_cat`, `posisi`, `name`, `jml`, `urutan`, `pub`) VALUES (2, 'Nasional', 2, 1, NULL, 2, 2, 0);
INSERT INTO `widget` (`id`, `title`, `id_cat`, `posisi`, `name`, `jml`, `urutan`, `pub`) VALUES (3, 'Politik', 3, 2, NULL, 1, 1, 0);


